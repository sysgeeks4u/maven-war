# Example Hello World WAR-File

Here little war file if you want to test your JBOSS.
The included war-file ist build with Java 21 temurin.

## How to use?
Download the war-file from the release and copy it to the _[jboss-home]/standalone/deployments/_ folder. JBOSS will automatically delpoy the project.

Now you can check if it has worked under http(s)://[your-jboss-adress-here]/helloworld/.
